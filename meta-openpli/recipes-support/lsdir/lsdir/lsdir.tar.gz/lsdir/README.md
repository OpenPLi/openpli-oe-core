# lsdir
Allows to list directory
