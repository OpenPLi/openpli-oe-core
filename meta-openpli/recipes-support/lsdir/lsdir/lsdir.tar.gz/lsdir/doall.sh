#!/bin/bash


./make.sh armv7
./make.sh armv5t
./make.sh sh4
./make.sh mipsel
./make.sh i686
