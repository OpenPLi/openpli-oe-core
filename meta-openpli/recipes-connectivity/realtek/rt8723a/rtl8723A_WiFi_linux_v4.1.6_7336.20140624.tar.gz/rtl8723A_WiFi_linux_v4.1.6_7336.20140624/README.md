Installing:
-----------
To get this file, you should have done
    git clone https://github.com/lwfinger/rtl8723au.git

To install, you need to run the following commands

    cd rtl8723au/
    make
    sudo make install
    sudo modprobe 8723au
    
    
From: [askubuntu][1]


[1]: http://askubuntu.com/a/358479/157129
